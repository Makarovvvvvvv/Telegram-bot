import logging
import random
import sqlite3
from datetime import datetime
from telegram.ext import Updater, CommandHandler
from apscheduler.schedulers.background import BackgroundScheduler
import requests
from bs4 import BeautifulSoup
import os

TOKEN = os.getenv("TOKEN", "7715618769:AAH4-rRgKAPvjD7WOneimKaqCBDTHqK-9K4")
GROUP_ID = "@+Vs0QuS-ALcZmNzcy"
TIMEZONE = "Europe/Moscow"

MOTIVATION = [
    "🚀 ПРИВЕТ, СОЛДАТЫ! Сегодня ваш день — пусть каждый выстрел будет в цель!",
    "🌞 Доброе утро, бойцы! Время завоевывать топовые ранги!",
    "🔥 ВНИМАНИЕ, ОТРЯД! Сегодня вы получите MVP даже в завтраке!"
]

conn = sqlite3.connect('news.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS news (link TEXT PRIMARY KEY)''')
conn.commit()

def is_new(link):
    cursor.execute("SELECT * FROM news WHERE link=?", (link,))
    return not cursor.fetchone()

def get_news():
    url = "https://www.reddit.com/r/CallOfDutyMobile/new/.json"
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        news = []
        for post in data['data']['children'][:5]:
            title = post['data']['title']
            link = post['data']['url']
            if is_new(link):
                news.append(f"📌 {title}\n🔗 {link}")
                cursor.execute("INSERT INTO news VALUES (?)", (link,))
                conn.commit()
        return news
    except Exception as e:
        logging.error(f"Ошибка при получении новостей: {e}")
        return []

def send_motivation(context):
    phrase = random.choice(MOTIVATION)
    date = datetime.now().strftime("%d.%m.%Y")
    message = (
        f"🗓 {date}\n\n"
        f"{phrase}\n\n"
        "▫️ Пусть лутанусы будут щедрыми\n"
        "▫️ Аирдропы — частыми\n"
        "▫️ А противники — слегка задерганными\n\n"
        "⚡ УДАЧНОГО ДНЯ НА ПОЛЯХ СРАЖЕНИЙ! ⚡"
    )
    context.bot.send_message(chat_id=GROUP_ID, text=message)

def send_news(context):
    news = get_news()
    if news:
        for item in news:
            context.bot.send_message(chat_id=GROUP_ID, text=item)
    else:
        context.bot.send_message(chat_id=GROUP_ID, text="🎮 Сегодня новостей пока нет...")

def start(update, context):
    context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚡ Бот активен! Новости и мотивация будут приходить автоматически!"
    )

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))

    scheduler = BackgroundScheduler(timezone=TIMEZONE)
    scheduler.add_job(send_motivation, 'cron', hour=8, minute=0)
    scheduler.add_job(send_news, 'cron', hour=12, minute=30)
    scheduler.add_job(send_news, 'cron', hour=18, minute=30)
    scheduler.start()

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()